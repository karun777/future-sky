PRAGMA user_version = 1;
CREATE TABLE realm (id TEXT PRIMARY KEY NOT NULL);
CREATE TABLE person (id TEXT PRIMARY KEY NOT NULL);
CREATE TABLE collective (id TEXT PRIMARY KEY NOT NULL);
CREATE TABLE held_key (
    id TEXT PRIMARY KEY NOT NULL, holder TEXT NOT NULL REFERENCES person,
    revoked INTEGER NOT NULL DEFAULT 0, expires INTEGER NOT NULL
);
CREATE TABLE capacity (
    person TEXT NOT NULL REFERENCES person, collective TEXT NOT NULL REFERENCES collective,
    role TEXT NOT NULL, ends INTEGER NOT NULL, PRIMARY KEY(person, collective, role)
);
CREATE TABLE portal (id TEXT PRIMARY KEY NOT NULL, steward TEXT NOT NULL REFERENCES collective);
CREATE TABLE record (
    portal TEXT NOT NULL REFERENCES portal, id TEXT NOT NULL, fields TEXT NOT NULL,
    withheld TEXT NOT NULL, stage TEXT NOT NULL, evidence TEXT NOT NULL,
    PRIMARY KEY(portal, id)
);
CREATE TABLE involvement (
    person TEXT NOT NULL REFERENCES person, portal TEXT NOT NULL, target TEXT NOT NULL,
    kind TEXT NOT NULL, ends INTEGER NOT NULL, PRIMARY KEY(person, portal, target, kind),
    FOREIGN KEY(portal, target) REFERENCES record
);
CREATE TABLE recognition (
    key TEXT NOT NULL REFERENCES held_key, portal TEXT NOT NULL, target TEXT NOT NULL,
    role TEXT NOT NULL, involvement TEXT NOT NULL, action TEXT NOT NULL,
    projection TEXT NOT NULL, revoked INTEGER NOT NULL DEFAULT 0, expires INTEGER NOT NULL,
    PRIMARY KEY(key, portal, target, role, action),
    FOREIGN KEY(portal, target) REFERENCES record
);
CREATE TABLE review_request (
    id TEXT PRIMARY KEY NOT NULL, actor TEXT NOT NULL REFERENCES person,
    collective TEXT NOT NULL REFERENCES collective, role TEXT NOT NULL,
    portal TEXT NOT NULL, undertaking TEXT NOT NULL, evidence TEXT NOT NULL,
    state TEXT NOT NULL CHECK(state = 'pending'),
    UNIQUE(portal, undertaking),
    FOREIGN KEY(portal, undertaking) REFERENCES record
);
