"""Application boundary for one configured undertaking per authenticated identity.

The hosting application supplies the verified identity and server-owned bindings.
This library evaluates current authority. It does not authenticate a caller.
"""
from dataclasses import asdict, dataclass
from types import MappingProxyType

from .decision import Principal, Refused
from .undertakings import decide

API_VERSION = 1


@dataclass(frozen=True)
class Binding:
    person: str
    key: str
    collective: str
    role: str
    portal: str
    target: str


class Desk:
    def __init__(self, store, bindings):
        self.store = store
        self.bindings = MappingProxyType(dict(bindings))

    def context(self, identity):
        binding = self.bindings.get(identity)
        if not isinstance(binding, Binding):
            raise Refused()
        context = asdict(binding)
        principal = Principal(self.store.realm, context.pop("person"))
        return principal, context

    def view(self, identity):
        principal, context = self.context(identity)
        result = decide(self.store, principal, **context)
        return dict(result, api_version=API_VERSION, realm=self.store.realm)

    def act(self, identity, request):
        if not isinstance(request, dict):
            raise Refused()
        expected = {"action", "command_id", "revision"}
        if request.get("action") == "receipt":
            expected.add("checksum")
        if (set(request) != expected or type(request.get("revision")) is not int
                or request["revision"] < 0
                or not all(isinstance(v, str) for k, v in request.items() if k != "revision")
                or request["action"] == "view"):
            raise Refused()
        principal, context = self.context(identity)
        return decide(self.store, principal, **context,
                      action=request["action"], command_id=request["command_id"],
                      checksum=request.get("checksum", ""),
                      expected_revision=request["revision"])
