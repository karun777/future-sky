"""The same current-authority check serves detail, collections, export and submission."""
import json
import re
import sqlite3
import time
from dataclasses import dataclass


class Refused(Exception):
    """Ordinary denial. Its public representation intentionally has no details."""


class Unavailable(Exception):
    """Store or policy evaluation failed."""


@dataclass(frozen=True)
class Principal:
    realm: str
    person: str


# A recognition names a precise record, capacity, involvement and action. All
# relationships must hold on the same row in the same realm and transaction.
RULES = """
SELECT r.id, r.fields, r.stage, r.evidence, g.projection, g.action
FROM recognition g
JOIN held_key k ON k.id = g.key
JOIN person a ON a.id = k.holder
JOIN portal p ON p.id = g.portal
JOIN collective c ON c.id = p.steward
JOIN capacity s ON (s.person, s.collective, s.role) = (a.id, c.id, g.role)
JOIN record r ON (r.portal, r.id) = (p.id, g.target)
JOIN involvement i ON (i.person, i.portal, i.target, i.kind) =
                      (a.id, p.id, r.id, g.involvement)
WHERE a.id = :actor AND k.id = :key AND p.id = :portal
  AND c.id = :collective AND s.role = :role
  AND (:target IS NULL OR r.id = :target)
  AND k.revoked = 0 AND g.revoked = 0
  AND min(k.expires, g.expires, s.ends, i.ends) > :now
ORDER BY r.id, g.action
"""


def project(row):
    fields = json.loads(row["fields"])
    names = json.loads(row["projection"])
    if not isinstance(fields, dict) or not isinstance(names, list) or not names:
        raise ValueError("Invalid projection")
    # Flat explicitly named strings only. Withheld data has a separate column.
    if not all(isinstance(n, str) and isinstance(fields.get(n), str) for n in names):
        raise ValueError("Invalid projected field")
    return {"id": row["id"], "fields": {n: fields[n] for n in names}}


def evaluate(store, principal, *, key, portal, collective, role, action,
             target=None, request_id=None, evidence=None, clock=time.time):
    """Use the adapter's principal and clock. Treat all selectors as untrusted."""
    if not isinstance(principal, Principal) or principal.realm != store.realm:
        raise Refused()
    if action not in ("list", "export", "detail", "request_review"):
        raise Refused()
    write = action == "request_review"
    if (action in ("detail", "request_review")) != (target is not None):
        raise Refused()
    try:
        with store.transaction(write) as db:
            params = dict(actor=principal.person, key=key, portal=portal,
                          collective=collective, role=role, target=target, now=int(clock()))
            rows = db.execute(RULES, params).fetchall()
            readable = [row for row in rows if row["action"] == "read"]
            if not readable:
                raise Refused()
            items = {r["id"]: project(r) for r in readable}
            for row in rows:
                if row["action"] != "request_review" or row["id"] not in items:
                    continue
                if row["stage"] != "ready":
                    continue
                pending = db.execute(
                    "SELECT * FROM review_request WHERE portal=? AND undertaking=?",
                    (portal, row["id"])).fetchone()
                if write:
                    return submit(db, params, row, pending, request_id, evidence)
                item = items[row["id"]]
                if pending:
                    item["review_state"] = "pending"
                else:
                    item["review_evidence"] = row["evidence"]
            if write:
                raise Refused()
            return {"records": list(items.values())}
    except (sqlite3.Error, ValueError, TypeError, KeyError, OverflowError) as exc:
        raise Unavailable() from exc


def submit(db, params, rule, pending, request_id, evidence):
    if not isinstance(request_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", request_id):
        raise Refused()
    if not evidence or evidence != rule["evidence"]:
        raise Refused()
    values = (request_id, params["actor"], params["collective"], params["role"],
              params["portal"], rule["id"], evidence, "pending")
    if pending:
        if tuple(pending) != values:
            raise Refused()
    else:
        if db.execute("SELECT 1 FROM review_request WHERE id=?", (request_id,)).fetchone():
            raise Refused()
        db.execute("""INSERT INTO review_request
            (id,actor,collective,role,portal,undertaking,evidence,state)
            VALUES (?,?,?,?,?,?,?,?)""", values)
    return {"request_id": request_id, "state": "pending"}
