"""Collective-owned handovers with an attributed response and explicit copy receipt."""
import hashlib
import json
import re
import sqlite3
import time

from .decision import Principal, Refused, RULES, Unavailable, project
from .store import Store


class UndertakingStore(Store):
    def validate(self, db):
        super().validate(db)
        versions = [r[0] for r in db.execute("SELECT version FROM handover_schema")]
        if versions != [1]:
            raise sqlite3.DatabaseError("Unsupported handover schema")


def schema(db):
    # Provision inside Store.create's open transaction. executescript would commit it.
    statements = [
        "CREATE TABLE handover_schema(version INTEGER NOT NULL)",
        "INSERT INTO handover_schema VALUES (1)",
        """CREATE TABLE undertaking(
            portal TEXT NOT NULL, target TEXT NOT NULL, source_portal TEXT NOT NULL,
            source_target TEXT NOT NULL, office TEXT NOT NULL, holder TEXT NOT NULL REFERENCES person,
            nominee TEXT REFERENCES person, state TEXT NOT NULL DEFAULT 'open',
            requester TEXT REFERENCES person, copy_text TEXT, copy_digest TEXT,
            PRIMARY KEY(portal,target), FOREIGN KEY(portal,target) REFERENCES record,
            FOREIGN KEY(source_portal,source_target) REFERENCES record)""",
        """CREATE TABLE handover_event(
            sequence INTEGER PRIMARY KEY, command_id TEXT UNIQUE NOT NULL,
            portal TEXT NOT NULL, target TEXT NOT NULL, actor TEXT NOT NULL REFERENCES person,
            collective TEXT NOT NULL REFERENCES collective, role TEXT NOT NULL, action TEXT NOT NULL,
            at INTEGER NOT NULL, digest TEXT NOT NULL, previous_holder TEXT, new_holder TEXT,
            FOREIGN KEY(portal,target) REFERENCES undertaking)""",
    ]
    for statement in statements:
        db.execute(statement)


TRANSITIONS = {
    "request": ("open", "awaiting response"),
    "accept": ("awaiting response", "accepted"),
    "decline": ("awaiting response", "declined"),
    "offer": ("accepted", "copy offered"),
    "receipt": ("copy offered", "received"),
}


def rules(db, context):
    return {row["action"]: row for row in db.execute(RULES, context)}


def digest(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def allowed(case, grants, person):
    actions = {action for action, (before, _) in TRANSITIONS.items()
               if action in grants and case["state"] == before}
    if person == case["requester"] or person != case["holder"]:
        actions -= {"accept", "decline", "receipt"}
    if "receive_copy" not in grants:
        actions.discard("receipt")
    if "succeed" in grants and case["nominee"] and case["state"] != "open":
        actions.add("succeed")
    return actions


def read_view(db, ctx, case, grants):
    view = project(grants["read"])
    view.update(state=case["state"], holder=case["holder"],
                collective=ctx["collective"], actions=sorted(allowed(case, grants, ctx["actor"])))
    if "offer" in view["actions"]:
        try:
            releasable_copy(db, ctx, case)
        except Refused:
            view["actions"].remove("offer")
    if "succeed" in view["actions"]:
        if designation(db, ctx, case) is None:
            view["actions"].remove("succeed")
        else:
            view["nominee"] = case["nominee"]
    view["history"] = [dict(row) for row in db.execute("""
        SELECT actor, collective, role, action, at, previous_holder, new_holder
        FROM handover_event WHERE portal=:portal AND target=:target ORDER BY sequence""", ctx)]
    view["revision"] = db.execute("""SELECT coalesce(max(sequence),0) FROM handover_event
        WHERE portal=:portal AND target=:target""", ctx).fetchone()[0]
    if case["copy_text"] is not None and "receive_copy" in grants and ctx["actor"] == case["holder"]:
        if digest(case["copy_text"]) != case["copy_digest"]:
            raise Unavailable()
        view["copy"] = case["copy_text"]
    return view


def releasable_copy(db, ctx, case):
    source = dict(ctx, portal=case["source_portal"], target=case["source_target"])
    grants = rules(db, source)
    if "read" not in grants or "release_copy" not in grants:
        raise Refused()
    released = project(grants["release_copy"])
    visible = project(grants["read"])["fields"]
    if not released["fields"].keys() <= visible.keys():
        raise Refused()
    # The recipient hashes exactly these bytes after reading the delivered snapshot.
    return json.dumps(released, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def offer_copy(db, ctx, case):
    content = releasable_copy(db, ctx, case)
    db.execute("""UPDATE undertaking SET copy_text=:content, copy_digest=:checksum
               WHERE portal=:portal AND target=:target""", dict(ctx, content=content, checksum=digest(content)))
    return digest(content)


def designation(db, ctx, case):
    # The mandate is for one office on one undertaking. Other roles are independent.
    params = dict(ctx, nominee=case["nominee"], office=case["office"])
    return db.execute("""SELECT min(i.ends,c.ends) AS ends FROM involvement i
        JOIN capacity c ON c.person=i.person AND c.collective=:collective AND c.role=:office
        WHERE i.person=:nominee AND i.portal=:portal AND i.target=:target AND i.kind='designated'
          AND min(i.ends,c.ends)>:now""", params).fetchone()


def succeed(db, ctx, case):
    eligible = designation(db, ctx, case)
    if eligible is None:
        raise Refused()
    params = dict(ctx, nominee=case["nominee"], previous=case["holder"])
    db.execute("""DELETE FROM involvement WHERE person=:previous AND portal=:portal
               AND target=:target AND kind='office-holder'""", params)
    db.execute("INSERT INTO involvement VALUES (:nominee,:portal,:target,'office-holder',:ends)",
               dict(params, ends=eligible["ends"]))
    db.execute("""UPDATE undertaking SET holder=:nominee, nominee=NULL
               WHERE portal=:portal AND target=:target""", params)


def decide(store, principal, *, key, collective, role, portal, target, action="view",
           command_id="", checksum="", expected_revision=None, clock=time.time):
    if not isinstance(principal, Principal) or principal.realm != store.realm:
        raise Refused()
    if action != "view" and not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", command_id):
        raise Refused()
    if (action == "receipt") != bool(checksum):
        raise Refused()
    if expected_revision is not None and (type(expected_revision) is not int or expected_revision < 0):
        raise Refused()
    try:
        with store.transaction(action != "view") as db:
            ctx = dict(key=key, collective=collective, role=role, portal=portal, target=target,
                       actor=principal.person, now=int(clock()))
            grants = rules(db, ctx)
            case = db.execute("SELECT * FROM undertaking WHERE portal=:portal AND target=:target",
                              ctx).fetchone()
            if not case or "read" not in grants:
                raise Refused()
            if action == "view":
                return read_view(db, ctx, case, grants)
            if action not in grants or action not in {*TRANSITIONS, "succeed"}:
                raise Refused()
            project(grants["read"])  # Fail closed on malformed viewing policy before mutation.
            prior = db.execute("SELECT * FROM handover_event WHERE command_id=?", (command_id,)).fetchone()
            if prior:
                if any(prior[k] != ctx[k] for k in ("actor", "collective", "role", "portal", "target")):
                    raise Refused()
                if prior["action"] != action or (action == "receipt" and prior["digest"] != checksum):
                    raise Refused()
                return {"recorded": command_id}
            if action not in allowed(case, grants, principal.person):
                raise Refused()
            if expected_revision is not None:
                revision = db.execute("""SELECT coalesce(max(sequence),0) FROM handover_event
                    WHERE portal=:portal AND target=:target""", ctx).fetchone()[0]
                if revision != expected_revision:
                    raise Refused()
            previous = successor = None
            if action == "succeed":
                previous, successor = case["holder"], case["nominee"]
                succeed(db, ctx, case)
            else:
                if action == "offer":
                    checksum = offer_copy(db, ctx, case)
                if action == "receipt":
                    if ("receive_copy" not in grants or not case["copy_text"]
                            or checksum != case["copy_digest"] or checksum != digest(case["copy_text"])):
                        raise Refused()
                params = dict(ctx, stage=TRANSITIONS[action][1], action=action)
                db.execute("""UPDATE undertaking SET state=:stage,
                    requester=CASE WHEN :action='request' THEN :actor ELSE requester END
                    WHERE portal=:portal AND target=:target""", params)
            db.execute("""INSERT INTO handover_event
                (command_id,portal,target,actor,collective,role,action,at,digest,previous_holder,new_holder)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)""", (command_id,portal,target,principal.person,collective,
                role,action,ctx["now"],checksum,previous,successor))
            return {"recorded": command_id}
    except (sqlite3.Error, ValueError, KeyError, IndexError, TypeError) as exc:
        raise Unavailable() from exc
