"""Version 1 SQLite store. Provision and snapshot only in private local directories."""
import sqlite3
from contextlib import closing, contextmanager
from pathlib import Path


class Store:
    def __init__(self, path, realm):
        self.path = Path(path)
        self.realm = realm

    def connect(self):
        uri = self.path.resolve().as_uri() + "?mode=rw"
        db = sqlite3.connect(uri, uri=True, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        return db

    def validate(self, db):
        version = db.execute("PRAGMA user_version").fetchone()[0]
        realms = [row[0] for row in db.execute("SELECT id FROM realm")]
        if version != 1 or realms != [self.realm]:
            raise sqlite3.DatabaseError("Invalid realm store")

    @classmethod
    def create(cls, path, realm, seed):
        store = cls(path, realm)
        # Exclusive creation prevents a retry from reseeding or overwriting a realm.
        store.path.touch(mode=0o600, exist_ok=False)
        try:
            with closing(store.connect()) as db, db:
                schema = Path(__file__).with_name("schema.sql").read_text()
                db.executescript("BEGIN IMMEDIATE;\n" + schema)
                db.execute("INSERT INTO realm VALUES (?)", (realm,))
                seed(db)
            return store
        except BaseException:
            store.path.unlink()
            raise

    @contextmanager
    def transaction(self, write=False):
        with closing(self.connect()) as db, db:
            db.execute("BEGIN IMMEDIATE" if write else "BEGIN")
            self.validate(db)
            yield db

    def copy_to(self, destination):
        """Operator-only full-realm snapshot or restore into a fresh file."""
        target = type(self)(destination, self.realm)
        target.path.touch(mode=0o600, exist_ok=False)
        try:
            with closing(self.connect()) as src, closing(target.connect()) as dst:
                self.validate(src)
                src.backup(dst)
                target.validate(dst)
                if dst.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                    raise sqlite3.DatabaseError("Incomplete copy")
            return target
        except BaseException:
            target.path.unlink()
            raise
